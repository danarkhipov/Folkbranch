(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,15965,t=>{"use strict";var e=t.i(507693),i=t.i(411504),a=t.i(799833);let o=t=>t.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),p=t=>Array.isArray(t)?t.map(t=>"mention"===t.type?t.props?.label??"":"link"===t.type?p(t.content):t.text??"").join(""):"";t.s(["personSheet",0,function({person:t,graph:n,pages:r,stories:l,avatar:d,t:s,lang:$}){let c=new Map(n.persons.map(t=>[t.id,t])),m=t=>{let e=c.get(t);return e&&!e.hidden?e:null},g=t=>`${o((0,a.T)(t)||s("Без названия"))}${(0,a.c)(t)?` <span class="soft">${o((0,a.c)(t))}</span>`:""}`,f=[["Родители",n.parentChild.filter(e=>e.childId===t.id).flatMap(t=>m(t.parentId)??[])],["Супруги",n.unions.filter(e=>e.aId===t.id||e.bId===t.id).flatMap(e=>m(e.aId===t.id?e.bId:e.aId)??[])],["Дети",n.parentChild.filter(e=>e.parentId===t.id).flatMap(t=>m(t.childId)??[])]].filter(([,t])=>t.length),h=(0,i.U)(t,n),b=[t.birthPlace,t.deathPlace].filter(Boolean),u=(t,e)=>e?`<section><h2>${o(s(t))}</h2>${e}</section>`:"";return`<!doctype html><html lang="${o($)}"><head><meta charset="utf-8"><title>${o((0,a.T)(t))}</title><style>
@page { margin: 16mm 14mm; }
body { font: 11pt/1.5 Georgia, 'Times New Roman', serif; color: #1f1a14; margin: 0; }
header { display: flex; gap: 14px; align-items: center; border-bottom: 1px solid #b9ae98; padding-bottom: 10px; margin-bottom: 12px; }
header img { width: 84px; height: 84px; border-radius: 50%; object-fit: cover; }
h1 { font-size: 22pt; font-weight: 500; margin: 0; }
h2 { font-size: 13pt; font-weight: 600; margin: 14px 0 4px; break-after: avoid; }
h3 { font-size: 11.5pt; margin: 8px 0 2px; }
p { margin: 0 0 6px; } .li { margin-left: 12px; } .soft { color: #6b604f; }
ul { margin: 0; padding-left: 18px; } li { margin: 0 0 3px; break-inside: avoid; }
blockquote { margin: 4px 0 8px 12px; font-style: italic; }
figure { margin: 6px 0; break-inside: avoid; } figure img { max-width: 100%; max-height: 90mm; } figcaption { font-size: 9pt; color: #6b604f; }
footer { margin-top: 16px; font-size: 8.5pt; color: #6b604f; }
</style></head><body>
<header>${d?`<img src="${o(d)}" alt="">`:""}<div><h1>${o((0,a.T)(t)||s("Без названия"))}</h1>${(0,a.c)(t)?`<p class="soft">${o((0,a.c)(t))}${b.length?` \xb7 ${o(b.join(" — "))}`:""}</p>`:""}</div></header>
${u("Хронология жизни",h.length?`<ul>${h.map(t=>`<li><b>${o(t.date)}</b>${null!==t.age?` <span class="soft">(${o(s("возраст"))} ${t.age})</span>`:""} ${o(s(t.title))}${t.note?`: ${o(t.note)}`:""}</li>`).join("")}</ul>`:"")}
${u("Семья",f.map(([t,e])=>`<p><b>${o(s(t))}:</b> ${e.map(g).join(", ")}</p>`).join(""))}
${u("Факты",t.facts.filter(t=>t.kind||(0,e.L)(t,s)).map(t=>`<p><b>${o(t.kind)}</b>${t.date?` ${o(t.date)}`:""}${t.place?`, ${o(t.place)}`:""}${(0,e.L)(t,s)?`. ${o((0,e.L)(t,s))}`:""}</p>`).join(""))}
${r.map(t=>u(t.title||"Биография",function t(e){return e.map(e=>{let i=o(p(e.content)),a=e.children?.length?t(e.children):"";return"heading"===e.type?`<h3>${i}</h3>${a}`:"bulletListItem"===e.type||"numberedListItem"===e.type||"checkListItem"===e.type?`<p class="li">• ${i}</p>${a}`:"quote"===e.type?`<blockquote>${i}</blockquote>${a}`:"image"===e.type&&"string"==typeof e.props?.url&&e.props.url.startsWith("/api/")?`<figure><img src="${o(e.props.url)}" alt=""><figcaption>${o(String(e.props.caption??""))}</figcaption></figure>`:i||a?`<p>${i}</p>${a}`:""}).join("")}(t.content))).join("")}
${u("Рассказы",l.map(t=>`<h3>${o(t.title||s("Рассказ"))}</h3>${t.body?`<p>${o(t.body)}</p>`:`<p class="soft">${o(s("Запись голоса, без текста"))}</p>`}`).join(""))}
${u("Источники",t.sources.filter(t=>t.title).map(t=>`<p>${o(t.title)}${t.ref?`, ${o(t.ref)}`:""}${t.page?`, ${o(t.page)}`:""}${t.record?`, ${o(s("запись"))} ${o(t.record)}`:""}${t.date?`, ${o(t.date)}`:""}</p>${t.transcription?`<blockquote>${o(t.transcription)}</blockquote>`:""}`).join(""))}
<footer>${o(s("Из семейного архива"))} \xb7 ${o(new Date().toLocaleDateString($))}</footer>
</body></html>`}])}]);