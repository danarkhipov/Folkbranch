module.exports=[397950,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_%5B___path%5D_route_actions_066eul0u3bri2.js.map