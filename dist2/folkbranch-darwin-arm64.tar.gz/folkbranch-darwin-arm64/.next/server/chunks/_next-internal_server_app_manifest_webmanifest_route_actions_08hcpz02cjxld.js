module.exports=[429058,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_manifest_webmanifest_route_actions_08hcpz02cjxld.js.map