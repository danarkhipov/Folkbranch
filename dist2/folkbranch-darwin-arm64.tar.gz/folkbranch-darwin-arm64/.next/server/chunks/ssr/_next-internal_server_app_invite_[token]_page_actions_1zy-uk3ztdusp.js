module.exports=[995354,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invite_%5Btoken%5D_page_actions_1zy-uk3ztdusp.js.map