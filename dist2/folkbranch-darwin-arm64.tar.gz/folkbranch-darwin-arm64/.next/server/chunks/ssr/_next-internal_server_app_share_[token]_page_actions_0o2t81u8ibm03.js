module.exports=[280907,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_share_%5Btoken%5D_page_actions_0o2t81u8ibm03.js.map