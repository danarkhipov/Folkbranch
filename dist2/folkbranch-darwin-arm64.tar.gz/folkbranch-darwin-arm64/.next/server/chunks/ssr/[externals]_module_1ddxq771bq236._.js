module.exports=[362562,(a,b,c)=>{b.exports=a.x("module",()=>require("module"))}];

//# sourceMappingURL=%5Bexternals%5D_module_1ddxq771bq236._.js.map