module.exports=[23311,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tell_%5Btoken%5D_page_actions_1p7ck1km5cdsu.js.map