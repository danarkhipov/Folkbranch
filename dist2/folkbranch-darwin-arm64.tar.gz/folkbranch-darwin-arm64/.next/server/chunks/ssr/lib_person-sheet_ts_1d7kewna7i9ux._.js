module.exports=[206947,a=>{"use strict";var b=a.i(995834),c=a.i(303773),d=a.i(911889);let e=a=>a.replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[a]),f=a=>Array.isArray(a)?a.map(a=>"mention"===a.type?a.props?.label??"":"link"===a.type?f(a.content):a.text??"").join(""):"";a.s(["personSheet",0,function({person:a,graph:g,pages:h,stories:i,avatar:j,t:k,lang:l}){let m=new Map(g.persons.map(a=>[a.id,a])),n=a=>{let b=m.get(a);return b&&!b.hidden?b:null},o=a=>`${e((0,d.T)(a)||k("Без названия"))}${(0,d.c)(a)?` <span class="soft">${e((0,d.c)(a))}</span>`:""}`,p=[["Родители",g.parentChild.filter(b=>b.childId===a.id).flatMap(a=>n(a.parentId)??[])],["Супруги",g.unions.filter(b=>b.aId===a.id||b.bId===a.id).flatMap(b=>n(b.aId===a.id?b.bId:b.aId)??[])],["Дети",g.parentChild.filter(b=>b.parentId===a.id).flatMap(a=>n(a.childId)??[])]].filter(([,a])=>a.length),q=(0,c.f)(a,g),r=[a.birthPlace,a.deathPlace].filter(Boolean),s=(a,b)=>b?`<section><h2>${e(k(a))}</h2>${b}</section>`:"";return`<!doctype html><html lang="${e(l)}"><head><meta charset="utf-8"><title>${e((0,d.T)(a))}</title><style>
@page { margin: 16mm 14mm; }
body { font: 11pt/1.5 Georgia, 'Times New Roman', serif; color: #1f1a14; margin: 0; }
header { display: flex; gap: 14px; align-items: center; border-bottom: 1px solid #b9ae98; padding-bottom: 10px; margin-bottom: 12px; }
header img { width: 84px; height: 84px; border-radius: 50%; object-fit: cover; }
h1 { font-size: 22pt; font-weight: 500; margin: 0; }
h2 { font-size: 13pt; font-weight: 600; margin: 14px 0 4px; break-after: avoid; }
h3 { font-size: 11.5pt; margin: 8px 0 2px; }
p { margin: 0 0 6px; } .li { margin-left: 12px; } .soft { color: #6b604f; }
ul { margin: 0; padding-left: 18px; } li { margin: 0 0 3px; break-inside: avoid; }
blockquote { margin: 4px 0 8px 12px; font-style: italic; }
figure { margin: 6px 0; break-inside: avoid; } figure img { max-width: 100%; max-height: 90mm; } figcaption { font-size: 9pt; color: #6b604f; }
footer { margin-top: 16px; font-size: 8.5pt; color: #6b604f; }
</style></head><body>
<header>${j?`<img src="${e(j)}" alt="">`:""}<div><h1>${e((0,d.T)(a)||k("Без названия"))}</h1>${(0,d.c)(a)?`<p class="soft">${e((0,d.c)(a))}${r.length?` \xb7 ${e(r.join(" — "))}`:""}</p>`:""}</div></header>
${s("Хронология жизни",q.length?`<ul>${q.map(a=>`<li><b>${e(a.date)}</b>${null!==a.age?` <span class="soft">(${e(k("возраст"))} ${a.age})</span>`:""} ${e(k(a.title))}${a.note?`: ${e(a.note)}`:""}</li>`).join("")}</ul>`:"")}
${s("Семья",p.map(([a,b])=>`<p><b>${e(k(a))}:</b> ${b.map(o).join(", ")}</p>`).join(""))}
${s("Факты",a.facts.filter(a=>a.kind||(0,b.L)(a,k)).map(a=>`<p><b>${e(a.kind)}</b>${a.date?` ${e(a.date)}`:""}${a.place?`, ${e(a.place)}`:""}${(0,b.L)(a,k)?`. ${e((0,b.L)(a,k))}`:""}</p>`).join(""))}
${h.map(a=>s(a.title||"Биография",function a(b){return b.map(b=>{let c=e(f(b.content)),d=b.children?.length?a(b.children):"";return"heading"===b.type?`<h3>${c}</h3>${d}`:"bulletListItem"===b.type||"numberedListItem"===b.type||"checkListItem"===b.type?`<p class="li">• ${c}</p>${d}`:"quote"===b.type?`<blockquote>${c}</blockquote>${d}`:"image"===b.type&&"string"==typeof b.props?.url&&b.props.url.startsWith("/api/")?`<figure><img src="${e(b.props.url)}" alt=""><figcaption>${e(String(b.props.caption??""))}</figcaption></figure>`:c||d?`<p>${c}</p>${d}`:""}).join("")}(a.content))).join("")}
${s("Рассказы",i.map(a=>`<h3>${e(a.title||k("Рассказ"))}</h3>${a.body?`<p>${e(a.body)}</p>`:`<p class="soft">${e(k("Запись голоса, без текста"))}</p>`}`).join(""))}
${s("Источники",a.sources.filter(a=>a.title).map(a=>`<p>${e(a.title)}${a.ref?`, ${e(a.ref)}`:""}${a.page?`, ${e(a.page)}`:""}${a.record?`, ${e(k("запись"))} ${e(a.record)}`:""}${a.date?`, ${e(a.date)}`:""}</p>${a.transcription?`<blockquote>${e(a.transcription)}</blockquote>`:""}`).join(""))}
<footer>${e(k("Из семейного архива"))} \xb7 ${e(new Date().toLocaleDateString(l))}</footer>
</body></html>`}])}];

//# sourceMappingURL=lib_person-sheet_ts_1d7kewna7i9ux._.js.map