module.exports=[227687,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_share_route_actions_0tpl991n--lqv.js.map