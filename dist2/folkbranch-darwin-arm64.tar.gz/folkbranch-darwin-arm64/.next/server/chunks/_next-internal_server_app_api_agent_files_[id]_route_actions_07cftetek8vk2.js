module.exports=[666427,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_agent_files_%5Bid%5D_route_actions_07cftetek8vk2.js.map