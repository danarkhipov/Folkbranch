globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Yyb4Vm-r039gSFu5QcMPo/_buildManifest.js",
    "static/Yyb4Vm-r039gSFu5QcMPo/_ssgManifest.js",
    "static/Yyb4Vm-r039gSFu5QcMPo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ljlnpromcmsa.js",
    "static/chunks/1iqy7q4o65_55.js",
    "static/chunks/2ytgadr5vmpq6.js",
    "static/chunks/3ecvvdjl-zsxh.js",
    "static/chunks/04gxgqu_qy7dx.js",
    "static/chunks/turbopack-077hmtqrhcoji.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    },
    "/invite/[token]/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    },
    "/setup/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    },
    "/share/[token]/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    },
    "/tell/[token]/page": {
      "otherChunks": [
        "static/chunks/0ljlnpromcmsa.js",
        "static/chunks/1iqy7q4o65_55.js",
        "static/chunks/2ytgadr5vmpq6.js",
        "static/chunks/3ecvvdjl-zsxh.js",
        "static/chunks/04gxgqu_qy7dx.js"
      ],
      "runtimeModuleIds": [
        422021
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
