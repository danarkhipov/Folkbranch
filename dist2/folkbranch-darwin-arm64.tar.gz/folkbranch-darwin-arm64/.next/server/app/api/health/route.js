var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[externals]__1cgyieoo-izv_._.js")
R.c("server/chunks/1z1d_next_dist_0diyckh0_jo6h._.js")
R.c("server/chunks/[root-of-the-server]__18g_d_b4zccv6._.js")
R.c("server/chunks/_0b630tmi4kosj._.js")
R.c("server/chunks/_0p8mi_pgg4765._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_1ryftkbeskq31.js")
R.m(599002)
module.exports=R.m(599002).exports
